javac Counter.java
javac DecThread.java
javac IncThread.java
javac Main.java
